@extends('layouts.app')

@section('content')

<h1>Химия</h1>

<a href="{{ route('auth.facebook') }}">Войти с помощью Facebook</a>

@endsection