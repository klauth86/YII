@extends('layouts.app')

@section('content')

<h1>О приложении</h1>

<div class="row">
Это приложение было создано ...
</div>

@endsection

