@extends('layouts.app')

@section('content')
<h1>Страница не найдена!</h1>
@endsection