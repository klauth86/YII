@extends('layouts.app')

@section('content')
<h1>Вы не авторизованы в FB!</h1>
@endsection