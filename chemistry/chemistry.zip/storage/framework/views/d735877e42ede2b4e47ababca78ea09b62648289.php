<?php $__env->startSection('content'); ?>
<h1>Events</h1>

<div>
<ul>
<?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li>

<table>
<tr>
<td><?php echo e($event->description); ?></td>
<td><?php echo e($event->start_date); ?></td>
<td><?php echo e($event->end_date); ?></td>
<td><?php echo e($event->is_active); ?></td>
<td>
<?php echo Form::open(['route' => ['events.edit', $event], 'method' => 'get']); ?>

<?php echo Form::submit('Редактировать', ['class' => 'btn btn-danger']); ?>

<?php echo Form::close(); ?>

</td>
<td>
<?php echo Form::open(['route' => ['events.destroy', $event], 'method' => 'delete']); ?>

<?php echo Form::submit('Удалить', ['class' => 'btn btn-danger']); ?>

<?php echo Form::close(); ?>

</td>
</tr>
</table>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<li>Nothing found!</li>
<?php endif; ?>
</ul>
</div>

<div>
<?php echo Form::open(['route' => ['events.create'], 'method' => 'get']); ?>

<?php echo Form::submit('Создать Event', ['class' => 'btn btn-danger']); ?>

<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/events/index.blade.php ENDPATH**/ ?>