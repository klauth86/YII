<!doctype html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Химия</title>

<div>Добро пожаловать на Химию, <?php echo \Session::has('id') ? \Session::get('id') : 'Гость'; ?></div>

<?php if(Session::has('id')): ?>
<a href="<?php echo e(route('main.index')); ?>">Основная</a>	
<a href="<?php echo e(route('main.settings')); ?>">Настройки</a>
<a href="<?php echo e(route('welcome.about')); ?>">О приложении</a>
<a href="<?php echo e(route('welcome.logout')); ?>">Выйти</a>
<?php endif; ?>

</head>

<body>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('jscontent'); ?>

</body>

</html><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/layouts/app.blade.php ENDPATH**/ ?>