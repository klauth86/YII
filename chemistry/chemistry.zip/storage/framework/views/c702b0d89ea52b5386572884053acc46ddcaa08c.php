<?php $__env->startSection('content'); ?>
<h1>Результаты по вашему поиску</h1>

<div>
<ul>
<?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li>

<div> <?php echo e($account->name); ?> <?php echo e($account->patronymic); ?> <?php echo e($account->surname); ?></div>
<image width="100px" height="100px" background="red"></image>

<table>
<tr>

<?php $__empty_2 = true; $__currentLoopData = $account->accountRefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
<td>
<a href="<?php echo e($ref->reference); ?>">1</a>
</td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
<td>-</td>
<?php endif; ?>

<tr>
</table>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<li>-</li>
<?php endif; ?>
</ul>
</div>

<?php echo e($accounts->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/main/index.blade.php ENDPATH**/ ?>