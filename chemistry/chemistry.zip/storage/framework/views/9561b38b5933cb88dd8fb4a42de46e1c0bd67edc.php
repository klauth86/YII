<?php $__env->startSection('content'); ?>
<h1>Sorry, the page is not found!</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/errors/404.blade.php ENDPATH**/ ?>