<?php $__env->startSection('content'); ?>

<h1>О приложении</h1>

<div class="row">
Это приложение было создано ...
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/welcome/about.blade.php ENDPATH**/ ?>