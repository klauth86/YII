<?php $__env->startSection('content'); ?>

<h1>Химия</h1>

<a href="<?php echo e(route('auth.facebook')); ?>">Войти с помощью Facebook</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache\www\host2.localhost\chemistry\resources\views/welcome/index.blade.php ENDPATH**/ ?>